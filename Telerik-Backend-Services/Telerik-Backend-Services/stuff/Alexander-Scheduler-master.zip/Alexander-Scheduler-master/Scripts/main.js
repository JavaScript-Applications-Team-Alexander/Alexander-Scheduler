// TODO: Add schedule controller when implemented.
import controller from 'Scripts/scheduleAddController.js';

controller.init('.cool');